
from django.urls import path, include
from . import views
urlpatterns = [
    path('', views.home, name = 'home'),
    path('stockpicker/', views.stockPicker, name = 'stockpicker'),
    path('stocktracker/', views.stockTracker, name = 'stocktracker'),
    path('signup/', views.signupaccount, name = 'signup'),
    path('logout/', views.logOut,name='logOut'),
    path('login/', views.logIn,name='logIn'),
]